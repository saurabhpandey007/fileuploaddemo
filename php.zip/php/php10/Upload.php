<body bgcolor="lightyellow"><h3><pre>
<?php

   $nm = $_POST["un"];
   $fname = $_FILES["ph"]["name"]; 
   $fsize = $_FILES["ph"]["size"];
   $type = $_FILES["ph"]["type"];
   $tmpname = $_FILES["ph"]["tmp_name"];
   
   echo "Hello $nm , ur selected photo details - <br>";
   echo "file name is - $fname <br>";
   echo "file size is - ".($fsize/1024)." <br>";
   echo "file type is - $type <br>";
   echo "tmp name is - $tmpname <br>";
   if(($fsize/1024)>200)
      echo "Sorry file size to large for upload. ur select < 200 kb file for upload.";
   else
   {    
    move_uploaded_file($tmpname,"d:/upload/$nm$fname");
    echo "Successfully Uploaded. " ;
   } 
?> 

