<body bgcolor="lightyellow">
<pre><h3>
 <form action="SendMail.php" method="post"> 
    To      <Input type="text" name="id" size="30"/>
    
    Subject <Input type="text" name="sub" size="60"/>
    
    Message 
            <textarea name="msg" cols="60" rows="6"></textarea>
    
          <input type="submit" value="Send Mail" />  
 </form>
</h3></pre>  
</body>