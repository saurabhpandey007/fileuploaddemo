<?php
require_once 'mail/class.phpmailer.php'; // like include function. 
$id = $_REQUEST["id"];
$sub = $_REQUEST["sub"];
$msg = $_REQUEST["msg"];
$mail = new PHPMailer(); // create a new object
$mail->IsSMTP(); // enable SMTP
$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
$mail->SMTPAuth = true; // authentication enabled
$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail
$mail->Host = "smtp.gmail.com";
$mail->Port = 465; // or 587
$mail->IsHTML(true);
$mail->Username = "anmoldaydreamer@gmail.com"; // jisse mail jana hai 
$mail->Password = "smoothcriminal";
$mail->SetFrom("anmoldaydreamer@gmail.com");
$mail->AddCC("manoj@agilesoftech.co.in");
$mail->Subject = $sub;
$mail->Body = $msg;
$mail->AddAddress($id);
$mail->AddAttachment("d:/upload/Pankajface.jpg");
if(!$mail->Send())
    echo "Mailer Error: " . $mail->ErrorInfo;
 else
    echo "Mail Successfully send..............";

/*
   OPEN THE PHP.INI FILE & 

 ;extension=php_openssl.dll  - UN COMMENT THIS LINE & restart all services. 


*/
?>
