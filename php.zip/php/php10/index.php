<body bgcolor="lightyellow">
    <pre><h3>
    <form action="Upload.php" method="POST" enctype="multipart/form-data">
        Name   <input type="text" name="un" placeholder="Enter ur name" />  
        
        Photo  <input type="file" name="ph" />
        
          <input type="submit" value="next" />
    </form>
    
</body>
