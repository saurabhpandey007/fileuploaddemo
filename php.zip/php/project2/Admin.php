<?php
class Admin 
{
   function connect()
   {
      $dsn = mysql_connect("localhost","root","");
      mysql_select_db("pandey",$dsn); 
   }
   function addEmp($nm,$sl,$dno,$mob) 
   {
      $this->connect();
      $r = mysql_query("call addEmp('$nm',$sl,$dno,'$mob')");
      mysql_close();
      if($r ==1)
         return "Employee Record Successfully Inserted.";
      else
         return "Sorry Employee Record not Inserted.";
   }  
   function getData() 
   {
      $this->connect();
      $r = mysql_query("call getData()");
      mysql_close();
      return $r;
   }  
   function delEmp($n) 
   {
      $this->connect();
      $r = mysql_query("call delEmp($n)");
      mysql_close();
   }  
   function getEmp($n) 
   {
      $this->connect();
      $r = mysql_query("call getEmp($n)");
      $rs = mysql_fetch_row($r);
      mysql_close();
      return $rs;
   }  
   function updEmp($no,$nm,$sl,$dno,$mob) 
   {
      $this->connect();
      $r = mysql_query("call updEmp($no,'$nm',$sl,$dno,'$mob')");
      mysql_close();
      if($r ==1)
         return "Employee Record Successfully Updated.";
      else
         return "Sorry Employee Record not Updated.";
   } 
} 

?>
