<body bgcolor="lightyellow">
   <?php
      $n = $_GET["t"];
      require_once 'Admin.php';
      $o = new Admin();
      $rs = $o->getEmp($n);
   ?>
 <form action="Update.php" method="post">
  <pre><h3>
  Employee Exist with following details - 

    Empno : <?php echo $n."<br>"; ?>
      <input type="hidden" name="no" value="<?php echo $n; ?>" />
    Ename : <input type="text" name="nm" value="<?php echo $rs[0]; ?>" placeholder="Enter Emp Name" />

    Salary: <input type="text" name="sl" value="<?php echo $rs[1]; ?>" placeholder="Enter Emp Salary" size="10"/>
 
    Deptno: <select name="dno">
               <option  value=<?php echo $rs[2]; ?>> Dept - <?php echo $rs[2]; ?></option>
               <option value="10">Dept 10</option>
               <option value="20">Dept 20</option>
               <option value="30">Dept 30</option>
               <option value="40">Dept 40</option>
            </select>
 
    Mobile: <input type="text" name="mob" maxlength="14" value="<?php echo $rs[3]; ?>"  placeholder="Enter Emp Mobile" />

       <input type="submit" value='Update' />
     

    <a href="Report.php">List of all Employee</a>
    </h3></pre>   
    <hr size="3" color="red" /> 
   </form>
   <font color="navy" face="Comic Sans MS" size="4">
 
 </body>
</html>
