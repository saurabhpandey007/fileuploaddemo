<?php
   $n = $_GET["t"]; 
   require_once 'Admin.php';
   $o = new Admin();
   $o->delEmp($n);
   header("location:Report.php");
?>
