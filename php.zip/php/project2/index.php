<body bgcolor="lightyellow">
  <form method="post">
    <pre><h3>
 
    Ename   <input type="text" name="nm" placeholder="Enter Emp Name" />

    Salary  <input type="text" name="sl" placeholder="Enter Emp Salary" size="10"/>
 
    Deptno  <select name="dno">
               <option value="10">Dept 10</option>
               <option value="20">Dept 20</option>
               <option value="30">Dept 30</option>
               <option value="40">Dept 40</option>
            </select>
 
    Mobile  <input type="text" name="mob" maxlength="10" placeholder="Enter Emp Mobile" />

       <input type="submit" value='Save' />
     

    <a href="Report.php">List of all Employee</a>
    </h3></pre>   
    <hr size="3" color="red" /> 
   </form>
   <font color="navy" face="Comic Sans MS" size="4">
   <?php
      if(isset($_POST["nm"]))// return true if parameter exist  
      {
        $nm = $_POST["nm"];
        $sl = $_POST["sl"];
        $dno = $_POST["dno"];
        $mob = $_POST["mob"];
        require_once 'Admin.php';
        $o = new Admin();
        $r = $o->addEmp($nm, $sl, $dno, $mob);
        echo $r;
      }  
   ?>
 
 </body>
</html>
