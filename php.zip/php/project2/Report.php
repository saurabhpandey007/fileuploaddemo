<body bgcolor="lightyellow">
 <center>
  <table border="1" width="95%">   
   <tr><th>Empno</th> <th>Ename</th><th>Salary</th><th>Deptno</th><th>DOJ</th><th>Mobile</th><th>Operation</th></tr>
   <?php
     require_once 'Admin.php'; 
     $o = new Admin();
     $r = $o->getData();
     for($i=0;$i<mysql_num_rows($r);$i++) //for all rows 
     {
        $rs = mysql_fetch_row($r); // fetch the current row from r
        echo "<tr>";
        foreach($rs as $a)
        {
          echo "<td>$a</td>";   
        }
        echo "<td><a href=DelEmp.php?t=$rs[0]>Delete</a> / <a href=UpdEmp.php?t=$rs[0]>Update</a>";
     }
   ?>
 </table></center> 
 <tt><h3><a href="index.php">Add new Employee</a>
</body>
