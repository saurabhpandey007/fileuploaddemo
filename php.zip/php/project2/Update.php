<?php
    $no = $_POST["no"];
    $nm = $_POST["nm"];
    $sl = $_POST["sl"];
    $dno = $_POST["dno"];
    $mob = $_POST["mob"];
    require_once 'Admin.php';
    $o = new Admin();
    $r = $o->updEmp($no,$nm, $sl, $dno, $mob);
    header("location:Report.php");
?>
