function view()
{
   document.getElementById("at").innerHTML="";
   document.getElementById("atm").style.display="block";
   
}