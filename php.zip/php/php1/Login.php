<link rel="stylesheet" href="FormDesign.css">
<script src="abc.js"></script>
<body bgcolor="lightyellow">
<div class="form">    
    <form action="Validate.php" enctype="multipart/form-data" method="post">
  
     <h3><pre>
       User Id  <input type="text" name="uid" class="fld" placeholder="Enter User Id" title="Plz enter ur User Id..."/> 
      
       Password <input type="password" name="ps" class="fld" size="13" placeholder="Enter Password" title="Plz enter ur password" /> 
       
       Upload   <input type="file" name="image" class="fld"> <u id="at" onclick="view()">AttachMore</u>
<div id="atm" style="display: none;">       Upload   <input type="file" name="image0" class="fld">
       Upload   <input type="file" name="image1" class="fld">
       Upload   <input type="file" name="image2" class="fld">
       Upload   <input type="file" name="image3" class="fld">
       Upload   <input type="file" name="image4" class="fld">
</div>       
         <input type="submit" class="btn" value=" " />
   </pre></h3> </form>
</div>   
</body>