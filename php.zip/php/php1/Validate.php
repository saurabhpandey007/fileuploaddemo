<?php
   $u = $_POST["uid"];
   $p = $_POST["ps"];
   $fName = $_FILES["image"]["name"];
   $tmpName  = $_FILES['image']['tmp_name'];
   $fSize = $_FILES['image']['size']; // for size limit 
   $fType = $_FILES['image']['type']; // for upload 
   $IMAGE = "photos/$u$fName";
   if(($fSize/1024)>500)
     echo "Sorry ur upload file in too large , plz upload < 500 kb files."; 
   else
   {
     echo "Hello Mr - $u<br>";
     echo "ur Photo is - $fName<br>";
     echo "temp Photo is - $tmpName<br>";
     echo "file size is - ".($fSize/1024)."kb.<br>";
     echo "File type is - $fType<br>";
     move_uploaded_file($tmpName, $IMAGE); // upload that file 
   }  
 ?>
