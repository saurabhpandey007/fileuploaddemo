<?php
  session_start();
  if(!isset($_SESSION["Id"]))
    header("location:SLogin.php?t=2"); 
  else
   $u = $_SESSION["Id"];
?>
<body bgcolor="lightyellow">
<h2><tt>Hello <?php echo $u; ?>, Welcome's U.<hr size="4" color="red">
   <a href="SProduct.php">Click here for Selecting products</a>
        