<body bgcolor="lightyellow">
 <h3><pre>
  <?php
   $u="";
   $p="";
   if(isset($_GET["t"]))
   {
     $t = $_GET["t"];
     if($t=="1")
       echo "Sorry this is Invalid Login id & password,re-enter Plz...";  
     else if($t=="0")
     {
       $u = "User id Can't Blank."    ;
       $p = "Password Can't Blank."  ;  
     }
   }      
  ?>
   <form action="Validate.php" method="post">
       User Id  <input type="text" name="uid" placeholder="Enter User Id" title="Plz enter ur User Id..."/> <?php echo $u; ?>
       
       Password <input type="password" name="ps" size="13" placeholder="Enter Password" title="Plz enter ur password" /> <?php echo $p; ?>
       
         <input type="submit" value="Sign In" />
   </form>
 </pre></h3>
</body>