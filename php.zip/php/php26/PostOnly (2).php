<body bgcolor="lightyellow"><tt><h2>
<?php
  if(isset($_POST["uid"])) // if uid is exist 
  {    
    $u = $_POST["uid"]; 
    $p = $_POST["ps"];
    echo "Hello Mr. $u, Welcome's U<br>";
    echo "ur password is - $p";
  }
  else
    echo "Sorry Post method is not accepted with this URL, contact to Admin.";   
?>
