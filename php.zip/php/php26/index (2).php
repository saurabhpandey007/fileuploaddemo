<body bgcolor="lightyellow">
 <h3><pre>
   <form action="GetPost.php" method="get">
       User Id  <input type="text" name="uid" placeholder="Enter User Id" title="Plz enter ur User Id..."/>
       
       Password <input type="password" name="ps" size="13" placeholder="Enter Password" title="Plz enter ur password" />
       
         <input type="submit" value="Sign In" />
   </form>
 </pre></h3>
</body>