<body bgcolor="lightyellow">
 <h3><pre>
  <?php
   # query String always GET se hi pass hoti hai.  
   $u="";
   $p="";
   if(isset($_GET["t"])) // check the query string available or not 
   {
     $t = $_GET["t"];
     if($t=="1") // 1 for invalid Login 
       echo "<font color=red>Sorry this is Invalid Login id & password,re-enter Plz...</font>";  
     else if($t=="0") // 0 for blank 
     {
       $u = "<font color=red>User id Can't Blank.</font>"    ;
       $p = "<font color=red>Password Can't Blank.</font>"  ;  
     }
     else // for direct calling. 
       echo "<font color=red>Sorry U can't Contd.. without Sign In,plz sign in 1st...</font>";    
   }      
  ?>
   <form action="SValidate.php" method="post">
       User Id  <input type="text" name="uid" placeholder="Enter User Id" title="Plz enter ur User Id..."/> 
                <?php echo $u."<br>"; ?>
       Password <input type="password" name="ps" size="13" placeholder="Enter Password" title="Plz enter ur password" /> 
                <?php echo $p."<br>"; ?>
         <input type="submit" value="Sign In" />
   </form>
 </pre></h3>
</body>