<?php
  if(!isset($_POST["uid"]))
    header("location:SLogin.php?t=2");  
  else
  {    
    $u = $_POST["uid"];
    $p = $_POST["ps"];
    if($u=="")
      header("location:SLogin.php?t=0");    
    else if($p=="pintu") // direct to Wel.php page
    {
      session_start(); 
      $_SESSION["Id"] = $u;  
      header("location:SWelcome.php");  
    }  
    else
      header("location:Login.php?t=1");    
  }  
?>
