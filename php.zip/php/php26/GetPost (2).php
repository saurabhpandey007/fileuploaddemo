<body bgcolor="lightyellow"><tt><h2>
<?php
  if(isset($_REQUEST["uid"])) // if uid is exist 
  {    
    $u = $_REQUEST["uid"]; 
    $p = $_REQUEST["ps"];
    echo "Hello Mr. $u, Welcome's U<br>";
    echo "ur password is - $p";
  }
  else // for direct open
  {
    echo "Sorry U can't Contd.. Sign In 1st.<br>";
    echo "<a href='index.php'>Click here for Login Page</a>";
  }
  
?>
