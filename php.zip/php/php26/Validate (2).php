<?php
  if(!isset($_POST["uid"]))
    header("location:index.php?t=2");  
  $u = $_POST["uid"];
  $p = $_POST["ps"];
  if($u=="")
    header("location:Login.php?t=0");    
  else if($p=="pintu") // direct to Wel.php page
    header("location:Wel.php");  
  else
    header("location:Login.php?t=1");    
?>
