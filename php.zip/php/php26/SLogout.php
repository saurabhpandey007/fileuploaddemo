<?php
  session_start();
  if(!isset($_SESSION["Id"]))
    header("location:SLogin.php?t=2"); 
  else
   $u = $_SESSION["Id"];
session_destroy();
?>
<body bgcolor="lightyellow">
<h2><tt>Hello <?php echo $u; ?>, U Successfully Logout.<hr size="4" color="red">
   <a href="SLogin.php">Click here for Login</a>
        