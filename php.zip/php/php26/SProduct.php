<?php
  session_start();
  if(!isset($_SESSION["Id"]))
    header("location:SLogin.php?t=2"); 
  else
   $u = $_SESSION["Id"];
?>
<body bgcolor="lightyellow">
<h2><tt>Hello <?php echo $u; ?>, Thanx for Choosing Us.<hr size="4" color="red">
   <a href="SLogout.php">Click here for Logout</a>
        